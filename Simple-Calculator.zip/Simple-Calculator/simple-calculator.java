import java.util.Scanner;

public class AdvancedCalculator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("=== Calculator ===");
            System.out.println("1 Add   2 Subtract   3 Multiply   4 Divide   0 Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();

            if (choice.equals("0")) {
                System.out.println("Bye!");
                break;
            }

            if (!choice.matches("[1-4]")) {
                System.out.println("Not a valid choice.\n");
                continue;
            }

            try {
                System.out.print("First number: ");
                double a = Double.parseDouble(sc.nextLine().trim());
                System.out.print("Second number: ");
                double b = Double.parseDouble(sc.nextLine().trim());

                switch (choice) {
                    case "1": System.out.println("Result: " + (a + b)); break;
                    case "2": System.out.println("Result: " + (a - b)); break;
                    case "3": System.out.println("Result: " + (a * b)); break;
                    case "4":
                        if (b == 0) System.out.println("Can't divide by zero.");
                        else System.out.println("Result: " + (a / b));
                        break;
                }
            } catch (NumberFormatException e) {
                System.out.println("That's not a valid number.");
            }
            System.out.println();
        }
    }
}
