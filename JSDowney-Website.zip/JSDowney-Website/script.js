const navToggle = document.querySelector('[data-nav-toggle]');
const nav = document.querySelector('[data-nav]');
const header = document.querySelector('.header');
const backTop = document.querySelector('.back-top');

function closeNav() {
  if (!nav || !navToggle) return;
  nav.classList.remove('open');
  navToggle.setAttribute('aria-expanded', 'false');
}

function openNav() {
  if (!nav || !navToggle) return;
  nav.classList.add('open');
  navToggle.setAttribute('aria-expanded', 'true');
}

if (navToggle && nav) {
  navToggle.addEventListener('click', () => {
    nav.classList.contains('open') ? closeNav() : openNav();
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeNav));
}

window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeNav();
});

const onScroll = () => {
  const y = window.scrollY || 0;
  if (header) header.classList.toggle('scrolled', y > 12);
  if (backTop) backTop.classList.toggle('show', y > 650);
};
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

if (backTop) {
  backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

const current = location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('[data-nav] a').forEach((a) => {
  const href = a.getAttribute('href');
  if (href === current) a.classList.add('active');
  if (current === '' && href === 'index.html') a.classList.add('active');
});

const revealEls = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && revealEls.length) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('show');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealEls.forEach(el => io.observe(el));
} else {
  revealEls.forEach(el => el.classList.add('show'));
}

function wireForm(formId, successId) {
  const form = document.getElementById(formId);
  const success = document.getElementById(successId);
  if (!form || !success) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    const old = button ? button.textContent : '';
    if (button) {
      button.disabled = true;
      button.textContent = 'Sending…';
    }
    window.setTimeout(() => {
      form.reset();
      form.hidden = true;
      success.hidden = false;
      success.scrollIntoView({ behavior: 'smooth', block: 'center' });
      if (button) {
        button.disabled = false;
        button.textContent = old;
      }
    }, 850);
  });
}

wireForm('quote-form', 'quote-success');
wireForm('contact-form', 'contact-success');
wireForm('payment-request-form', 'payment-success');



const searchForms = document.querySelectorAll('[data-site-search-form]');
const searchIndex = [
  { terms: ['home', 'main', 'start'], url: 'index.html' },
  { terms: ['about', 'team', 'agency'], url: 'about.html' },
  { terms: ['testimonials', 'reviews', 'feedback'], url: 'testimonials.html' },
  { terms: ['carriers', 'carrier', 'health plans'], url: 'carriers.html' },
  { terms: ['news', 'blog', 'articles'], url: 'news.html' },
  { terms: ['contact', 'phone', 'email'], url: 'contact.html' },
  { terms: ['personal lines', 'personal', 'auto', 'home'], url: 'personal-lines.html' },
  { terms: ['business lines', 'business', 'commercial'], url: 'business-lines.html' },
  { terms: ['quote', 'get a quote'], url: 'quote.html' },
  { terms: ['payment', 'make a payment'], url: 'make-a-payment.html' },
];

function normalize(str) {
  return (str || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function goToSearch(query) {
  const q = normalize(query);
  if (!q) return;
  const found = searchIndex.find(item => item.terms.some(term => q.includes(term)));
  if (found) {
    window.location.href = found.url;
    return;
  }
  const candidates = Array.from(document.querySelectorAll('h1, h2, h3, p, li, a'));
  const target = candidates.find(el => normalize(el.textContent).includes(q));
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    target.classList.add('search-hit');
    window.setTimeout(() => target.classList.remove('search-hit'), 1800);
    return;
  }
  window.location.href = 'news.html';
}

searchForms.forEach((form) => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = form.querySelector('[data-site-search-input]');
    goToSearch(input ? input.value : '');
  });
});

const clickableCards = document.querySelectorAll('[data-href]');
clickableCards.forEach((el) => {
  el.classList.add('clickable-card');
  el.setAttribute('role', 'link');
  el.tabIndex = 0;
  const href = el.getAttribute('data-href');
  const activate = () => { if (href) window.location.href = href; };
  el.addEventListener('click', activate);
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      activate();
    }
  });
});

window.addEventListener('load', () => {
  document.body.classList.add('is-loaded');
  const loader = document.getElementById('site-loader');
  if (loader) {
    window.setTimeout(() => loader.remove(), 350);
  }
});
