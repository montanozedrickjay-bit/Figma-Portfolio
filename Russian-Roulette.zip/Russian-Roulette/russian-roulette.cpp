#include <iostream>
#include <random>
#include <string>
#include <algorithm>
#include <cctype>

int main() {
    const int CHAMBERS = 8;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, CHAMBERS - 1);
    const int bulletChamber = dist(gen);

    int currentChamber = 0;
    int emptyShots = 0;

    std::cout << "=== Russian Roulette ===\n";
    std::cout << "8 chambers, 1 bullet. Shoot or pass.\n";
    std::cout << "Survive all 7 empty chambers to win. Get shot once and you lose.\n\n";

    while (true) {
        std::cout << "Empty shots so far: " << emptyShots << "/7\n";
        std::cout << "Type shoot or pass (s/p): ";

        std::string input;
        if (!std::getline(std::cin, input)) {
            break;
        }

        std::transform(input.begin(), input.end(), input.begin(),
                       [](unsigned char c) { return std::tolower(c); });

        if (input == "pass" || input == "p") {
            std::cout << "You pass. Nothing happens.\n\n";
        } else if (input == "shoot" || input == "s") {
            std::cout << "You pull the trigger...\n";

            if (currentChamber == bulletChamber) {
                std::cout << "BANG! You got shot. You lose.\n";
                break;
            }

            std::cout << "Click. Empty chamber.\n\n";
            emptyShots++;
            currentChamber++;

            if (emptyShots == CHAMBERS - 1) {
                std::cout << "You shot all 7 empty chambers. You win!\n";
                break;
            }
        } else {
            std::cout << "Please type 'shoot' or 'pass'.\n\n";
        }
    }

    return 0;
}
