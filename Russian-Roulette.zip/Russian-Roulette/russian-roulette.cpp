#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    srand(time(0));
    int bullet = rand() % 6;
    int chamber = 0;
    int safeShots = 0;
    char choice;

    cout << "Russian Roulette\n";
    cout << "If you shot all 5 empty chambers, you win.\n";
    cout << "If you get shot, you lose.\n\n";
    
    while (true) {
        cout << "Shoot (s) or Pass (p)? ";
        cin >> choice;

        if (choice == 's') {
            if (chamber == bullet) {
                cout << "BANG! You lose.\n";
                break;
            }
            cout << "Click. Empty.\n";
            chamber++;
            safeShots++;

            cout << "Safe shots: " << safeShots << "/5\n";

            if (safeShots == 5) {
                cout << "You shot all 5 empty chambers. You win!\n";
                break;
            }
        } else if (choice == 'p') {
            cout << "You passed.\n";
        } else {
            cout << "Type s or p.\n";
        }
    }

    return 0;
}